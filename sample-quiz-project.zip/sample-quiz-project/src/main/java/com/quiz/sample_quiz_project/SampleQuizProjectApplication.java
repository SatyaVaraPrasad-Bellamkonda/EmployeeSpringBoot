package com.quiz.sample_quiz_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleQuizProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleQuizProjectApplication.class, args);
	}

}
