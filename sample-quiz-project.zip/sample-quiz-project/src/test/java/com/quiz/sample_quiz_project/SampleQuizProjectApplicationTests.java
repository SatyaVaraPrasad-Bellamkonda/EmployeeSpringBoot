package com.quiz.sample_quiz_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleQuizProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
